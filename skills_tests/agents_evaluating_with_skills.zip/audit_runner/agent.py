import os
import pathlib

from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools.mcp_tool import McpToolset, StdioConnectionParams
from mcp import StdioServerParameters

load_dotenv()

EVAL_FRAMEWORK = pathlib.Path(r"c:\Users\Raph\Prj\kaggle_ai_agent_course\eval_framework")
SKILLS = EVAL_FRAMEWORK / "skills" / "loops_mcp"
L1_REPO = r"c:\Users\Raph\Prj\kaggle_ai_agent_course\agents_evaluated_with_skills"
PYTHON = r"C:\Users\Raph\anaconda3\envs\eval_framework\python.exe"

# Honoured by eval_workbench exec_script via RunConfig.max_llm_calls.
# Governance audits need many tool rounds (list → get_case drills → report).
MAX_LLM_CALLS = 80

SKILL_NAME = "audit"
SKILL_DIR = SKILLS / "audit"
SKILL_DESCRIPTION = (
    "Governance and coverage audit for an ADK agent snapshot via eval-workbench MCP: "
    "concern-tag semantics, distribution hygiene, NIST AI RMF concern_coverage vs "
    "cases, and business_case vs token cost."
)


def list_skills() -> dict:
    """List available loop skills for this runner."""
    return {"skills": [{"name": SKILL_NAME, "description": SKILL_DESCRIPTION}]}


def load_skill(skill_name: str) -> dict:
    """Load SKILL.md instructions for the named skill."""
    if skill_name not in {SKILL_NAME, SKILL_NAME.replace("-", "_")}:
        return {"error": f"unknown skill {skill_name}"}
    body = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    return {"skill_name": SKILL_NAME, "instructions": body}


l1_mcp = McpToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command=PYTHON,
            args=[
                str(EVAL_FRAMEWORK / "run_app.py"),
                L1_REPO,
                "--mode",
                "mcp",
                "--api-url",
                "http://127.0.0.1:5000",
            ],
            env={
                **os.environ,
                "PYTHONPATH": str(EVAL_FRAMEWORK / "src"),
                "EVAL_WORKBENCH_API_URL": "http://127.0.0.1:5000",
            },
        ),
        timeout=120.0,
    ),
)

root_agent = Agent(
    name="audit_runner",
    model="gemini-2.5-flash",
    description="Governance and coverage audit loop for L1 agents",
    instruction="""
You are the audit loop agent.

1. Call `list_skills`, then `load_skill` for your skill before anything else.
2. Follow the loaded skill using L1 eval-workbench MCP tools.
3. Keep going through the skill phases until the structured audit report is written.
   Many tool rounds are expected; do not stop after the first few MCP calls.
4. Use full snapshot ids (`commit:module.path:var`), never a bare commit hash.

Do not invent snapshot ids — list and get them from MCP when needed.
""",
    tools=[list_skills, load_skill, l1_mcp],
)
