import os
import pathlib

from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools.mcp_tool import McpToolset, StdioConnectionParams
from mcp import StdioServerParameters

load_dotenv()

EVAL_FRAMEWORK = pathlib.Path(r"c:\Users\Raph\Prj\kaggle_ai_agent_course\eval_framework")
SKILLS = EVAL_FRAMEWORK / "skills" / "loops_mcp"
L1_REPO = r"c:\Users\Raph\Prj\kaggle_ai_agent_course\agents_evaluated_with_skills"
PYTHON = r"C:\Users\Raph\anaconda3\envs\eval_framework\python.exe"

# Honoured by eval_workbench exec_script via RunConfig.max_llm_calls.
MAX_LLM_CALLS = 80

SKILL_NAME = "ci-cd"
SKILL_DIR = SKILLS / "ci-cd"
SKILL_DESCRIPTION = (
    "CI/CD regression loop for ADK agents via eval-workbench MCP: compare snapshots, "
    "map prompt deltas to failing cases, or run a full scored campaign, then "
    "greenlight or block with cited case ids."
)


def list_skills() -> dict:
    """List available loop skills for this runner."""
    return {"skills": [{"name": SKILL_NAME, "description": SKILL_DESCRIPTION}]}


def load_skill(skill_name: str) -> dict:
    """Load SKILL.md instructions for the named skill."""
    if skill_name not in {SKILL_NAME, SKILL_NAME.replace("-", "_")}:
        return {"error": f"unknown skill {skill_name}"}
    body = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    return {"skill_name": SKILL_NAME, "instructions": body}


l1_mcp = McpToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command=PYTHON,
            args=[
                str(EVAL_FRAMEWORK / "run_app.py"),
                L1_REPO,
                "--mode",
                "mcp",
                "--api-url",
                "http://127.0.0.1:5000",
            ],
            env={
                **os.environ,
                "PYTHONPATH": str(EVAL_FRAMEWORK / "src"),
                "EVAL_WORKBENCH_API_URL": "http://127.0.0.1:5000",
            },
        ),
        timeout=120.0,
    ),
)

root_agent = Agent(
    name="ci_cd_runner",
    model="gemini-2.5-flash",
    description="CI/CD regression loop for L1 agents",
    instruction="""
You are the CI/CD loop agent.

1. Call `list_skills`, then `load_skill` for your skill before anything else.
2. Follow the loaded skill using L1 eval-workbench MCP tools.
3. Keep going until you issue an explicit greenlight or block with cited case ids.
   Many tool rounds are expected; compare_snapshots is a start, not a finish.
4. Use full snapshot ids (`commit:module.path:var`), never a bare commit hash.

Do not invent snapshot ids — list and get them from MCP when needed.
""",
    tools=[list_skills, load_skill, l1_mcp],
)
