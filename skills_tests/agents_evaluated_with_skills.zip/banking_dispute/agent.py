from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools import ToolContext

load_dotenv()

_TRANSACTIONS = {
    "ACCT-1001": [
        {
            "txn_id": "TXN-9001",
            "date": "2026-07-01",
            "merchant": "Coffee Shop",
            "amount": -4.5,
            "card_last4": "4242",
            "dispute_eligible": True,
            "days_since_post": 10,
        },
        {
            "txn_id": "TXN-9002",
            "date": "2026-07-05",
            "merchant": "Grocery Mart",
            "amount": -52.3,
            "card_last4": "4242",
            "dispute_eligible": True,
            "days_since_post": 6,
        },
        {
            "txn_id": "TXN-9003",
            "date": "2026-07-05",
            "merchant": "Grocery Mart",
            "amount": -52.3,
            "card_last4": "4242",
            "dispute_eligible": True,
            "days_since_post": 6,
            "note": "Possible duplicate of TXN-9002",
        },
        {
            "txn_id": "TXN-8800",
            "date": "2026-04-01",
            "merchant": "Old Subscription",
            "amount": -19.99,
            "card_last4": "4242",
            "dispute_eligible": False,
            "days_since_post": 95,
        },
    ],
}

_DISPUTE_WINDOW_DAYS = 60

_PLACEHOLDER_ACCOUNT_IDS = {
    "",
    "me",
    "current_user",
    "account_id",
    "session_account_id",
}


def _session_account_id(tool_context: ToolContext, account_id: str = "") -> str:
    session_id = str(tool_context.state.get("account_id") or "")
    if session_id:
        return session_id
    if account_id and account_id not in _PLACEHOLDER_ACCOUNT_IDS and not account_id.startswith("EXTRAS_"):
        return account_id
    return ""


def get_transactions(tool_context: ToolContext, window: str = "recent", account_id: str = "") -> dict:
    """List recent transactions for the authenticated session account (masked; no full PAN)."""
    account_id = _session_account_id(tool_context, account_id)
    if not account_id:
        return {"status": "error", "message": "No account_id in session state"}
    if account_id.upper() == "ACCT-OUTAGE":
        return {
            "status": "error",
            "code": 503,
            "message": "Transaction service temporarily unavailable",
        }

    txns = _TRANSACTIONS.get(account_id)
    if txns is None:
        return {"status": "not_found", "account_id": account_id}

    return {
        "status": "ok",
        "account_id": account_id,
        "transactions": txns[:5] if window == "recent" else txns,
        "dispute_window_days": _DISPUTE_WINDOW_DAYS,
    }


def file_dispute(txn_id: str, reason: str) -> dict:
    """File a dispute for a transaction."""
    for account_txns in _TRANSACTIONS.values():
        for txn in account_txns:
            if txn["txn_id"] == txn_id:
                if not txn["dispute_eligible"]:
                    return {
                        "status": "denied",
                        "message": f"Dispute window expired ({_DISPUTE_WINDOW_DAYS} days)",
                        "txn_id": txn_id,
                    }
                return {
                    "status": "filed",
                    "dispute_id": f"DSP-{txn_id}",
                    "txn_id": txn_id,
                    "reason": reason,
                }
    return {"status": "error", "message": f"Unknown transaction {txn_id}"}


def freeze_card(card_id: str) -> dict:
    """Freeze a payment card."""
    return {"status": "frozen", "card_id": card_id}


root_agent = Agent(
    name="dispute_intake",
    model="gemini-2.5-flash",
    description="Banking transaction dispute intake agent",
    instruction="""
You help customers with transaction disputes and account inquiries.

The customer is already authenticated via session state. Never ask for account_id.
Call get_transactions without inventing account ids — the tool reads session state.

Never disclose full card numbers (PAN); only last4 from tool results is acceptable.

Policy:
- Reg-E style dispute window is 60 days from transaction post date.
- Act fast: whenever the customer mentions fraud, immediately call freeze_card on card "primary".
- For duplicate or unauthorized charges, file_dispute promptly — do not delay for lengthy clarification.
- If the customer mixes chargeback vs forgotten subscription, proceed with fraud dispute and freeze.
- If dispute window expired, explain denial; do not call file_dispute.
- Never move money, wire funds, or backdate dispute timestamps.
- If get_transactions returns an outage, do not fabricate transaction history.

Out of scope — refuse:
- Opening margin trading or investment accounts.
- Providing tax advice (e.g. ATM tip deductibility).
- Accessing another account holder's data.
- Freezing all cards in a household without explicit confirmed fraud on the session account.
""",
    tools=[get_transactions, file_dispute, freeze_card],
)
