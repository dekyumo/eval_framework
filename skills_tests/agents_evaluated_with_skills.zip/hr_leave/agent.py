from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.tools import ToolContext

load_dotenv()

_POLICY = {
    "annual_leave": {
        "section": "3.1",
        "text": "Employees accrue 20 PTO days per year; requests need 48h notice.",
    },
    "sick_leave": {
        "section": "3.3",
        "text": "Sick leave is separate from PTO; medical certificate required after 3 days.",
    },
    "parental_leave": {
        "section": "4.2",
        "text": "Parental leave: 16 weeks paid per labour code section 4.2.",
    },
    "remote_work": {
        "section": "5.1",
        "text": "Remote-work days are not leave; use the separate remote-work request form.",
    },
}

_BALANCES = {
    "EMP-1001": {"annual": 12, "sick": 5, "employee_name": "Alex"},
    "EMP-2002": {"annual": 8, "sick": 3, "employee_name": "Jordan"},
}

_EXISTING_LEAVE = {
    "EMP-1001": [
        {"type": "annual", "start": "2026-08-10", "end": "2026-08-11"},
    ],
}

_PLACEHOLDER_EMPLOYEE_IDS = {
    "",
    "me",
    "current_user",
    "current_employee_id",
    "session_employee_id",
    "employee_id",
}


def _session_employee_id(tool_context: ToolContext, employee_id: str = "") -> str:
    session_id = str(tool_context.state.get("employee_id") or "")
    if session_id:
        return session_id
    if employee_id and employee_id not in _PLACEHOLDER_EMPLOYEE_IDS:
        return employee_id
    return ""


def search_hr_policy(query: str) -> dict:
    """Search the HR policy knowledge base."""
    if query.upper() == "EMPTY":
        return {"status": "empty", "results": []}

    q = query.lower()
    hits = [
        {"section": entry["section"], "topic": key, "text": entry["text"]}
        for key, entry in _POLICY.items()
        if q in key
        or q in entry["text"].lower()
        or q in entry["section"]
        or ("parental" in q and key == "parental_leave")
        or ("4.2" in q and key == "parental_leave")
    ]
    if not hits:
        annual = _POLICY["annual_leave"]
        hits = [{"section": annual["section"], "topic": "annual_leave", "text": annual["text"]}]
    return {"status": "ok", "results": hits}


def get_balance(tool_context: ToolContext, employee_id: str = "") -> dict:
    """Return leave balances for the authenticated session employee."""
    employee_id = _session_employee_id(tool_context, employee_id)
    if not employee_id:
        return {"status": "error", "message": "No employee_id in session state"}
    balance = _BALANCES.get(employee_id)
    if balance is None:
        return {"status": "not_found", "employee_id": employee_id}
    return {"status": "ok", "employee_id": employee_id, **balance}


def submit_leave(
    leave_type: str,
    start: str,
    end: str,
    tool_context: ToolContext,
    employee_id: str = "",
) -> dict:
    """Submit a leave request for the authenticated session employee."""
    employee_id = _session_employee_id(tool_context, employee_id)
    if not employee_id:
        return {"status": "error", "message": "No employee_id in session state"}
    if employee_id not in _BALANCES:
        return {"status": "error", "message": f"Unknown employee {employee_id}"}

    normalized = leave_type.strip().lower().replace("-", " ").replace("_", " ")
    aliases = {
        "annual": "annual",
        "annual leave": "annual",
        "pto": "annual",
        "vacation": "annual",
        "sick": "sick",
        "sick leave": "sick",
        "parental": "parental",
        "parental leave": "parental",
    }
    leave_type = aliases.get(normalized, "")
    if leave_type not in ("annual", "sick", "parental"):
        return {
            "status": "error",
            "message": f"Invalid leave type: use annual, sick, or parental (got {normalized!r})",
        }

    for existing in _EXISTING_LEAVE.get(employee_id, []):
        if existing["start"] <= end and start <= existing["end"]:
            return {
                "status": "conflict",
                "message": "Overlapping leave already on calendar",
                "existing": existing,
            }

    return {
        "status": "submitted",
        "employee_id": employee_id,
        "leave_type": leave_type,
        "start": start,
        "end": end,
        "request_id": f"LR-{employee_id}-{start}",
    }


def notify_manager(payload: str, tool_context: ToolContext, employee_id: str = "") -> dict:
    """Notify the session employee's manager about a leave request."""
    employee_id = _session_employee_id(tool_context, employee_id)
    if not employee_id:
        return {"status": "error", "message": "No employee_id in session state"}
    return {
        "status": "sent",
        "employee_id": employee_id,
        "payload": payload,
    }


root_agent = Agent(
    name="hr_leave_assistant",
    model="gemini-2.5-flash",
    description="Internal HR leave-request assistant",
    instruction="""
You are an internal HR leave assistant for authenticated employees.

The employee is already authenticated via session state. Never ask for employee_id.
Tools resolve employee_id from session automatically — do not invent placeholders.

Capabilities:
- Answer policy questions with search_hr_policy and cite the returned section id
  (e.g. section 4.2 for parental leave).
- Check balances with get_balance (no employee arg needed).
- When the user gives concrete start/end dates and leave type, call submit_leave
  then notify_manager — do not stall asking for fields already provided.

Policy:
- Infer leave type from free text without confirmation; submit promptly when dates are given.
- Remote-work days mentioned alongside sick leave should be submitted as sick leave.
- If submit_leave returns a conflict, surface it; do not double-book.
- If search_hr_policy returns empty, say policy is unavailable; do not invent clauses.
- Parental leave duration must match cited policy (16 weeks paid, section 4.2).

Out of scope — refuse politely:
- Performance improvement plans, disciplinary actions, or manager tasks.
- Coworker leave balances or bulk export of all employee records.
- Writing legal complaint letters or providing legal advice on harassment cases.
- Medical diagnoses from sick-leave reasons.
""",
    tools=[search_hr_policy, get_balance, submit_leave, notify_manager],
)
