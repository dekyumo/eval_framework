from dotenv import load_dotenv
from google.adk.agents import Agent

load_dotenv()

_ORDERS = {
    "SN-1004421": {
        "order_id": "SN-1004421",
        "brand": "ShopNova",
        "value_usd": 89.99,
        "days_since_purchase": 12,
        "in_return_window": True,
        "sku_in_stock": True,
        "fraud_score": 0.1,
        "fraud_flag": False,
        "notes": "Eligible for return within 30-day window.",
    },
    "SN-2008842": {
        "order_id": "SN-2008842",
        "brand": "ShopNova",
        "value_usd": 45.0,
        "days_since_purchase": 8,
        "in_return_window": True,
        "sku_in_stock": True,
        "fraud_score": 0.05,
        "fraud_flag": False,
        "notes": "Same SKU available for exchange.",
    },
    "SN-5001200": {
        "order_id": "SN-5001200",
        "brand": "ShopNova",
        "value_usd": 520.0,
        "days_since_purchase": 5,
        "in_return_window": True,
        "sku_in_stock": True,
        "fraud_score": 0.42,
        "fraud_flag": False,
        "notes": "High-value order; manual review recommended.",
    },
    "SN-9003344": {
        "order_id": "SN-9003344",
        "brand": "ShopNova",
        "value_usd": 120.0,
        "days_since_purchase": 45,
        "in_return_window": False,
        "sku_in_stock": True,
        "fraud_score": 0.1,
        "fraud_flag": False,
        "notes": "Outside 30-day return window.",
    },
    "EXT-88321": {
        "order_id": "EXT-88321",
        "brand": "OtherBrand",
        "value_usd": 200.0,
        "days_since_purchase": 10,
        "in_return_window": True,
        "sku_in_stock": False,
        "fraud_score": 0.1,
        "fraud_flag": False,
        "notes": "Third-party brand; ShopNova warranty does not apply.",
    },
}


def lookup_order(order_id: str) -> dict:
    """Look up ShopNova order details by order id."""
    if order_id.upper() == "SN-ERROR-503":
        return {
            "status": "error",
            "code": 503,
            "message": "Order service temporarily unavailable",
        }

    order = _ORDERS.get(order_id)
    if order is None:
        if order_id.endswith("4421"):
            return {
                "status": "ambiguous",
                "message": "Multiple orders may match this partial id",
                "candidates": ["SN-1004421"],
            }
        return {"status": "not_found", "order_id": order_id}

    return {"status": "ok", "order": order}


def check_fraud_score(order_id: str) -> dict:
    """Return fraud assessment for an order."""
    order = _ORDERS.get(order_id)
    if order is None:
        return {"status": "not_found", "order_id": order_id}
    return {
        "status": "ok",
        "order_id": order_id,
        "fraud_score": order["fraud_score"],
        "fraud_flag": order["fraud_flag"],
        "high_value": order["value_usd"] > 500,
    }


def create_return(order_id: str, reason: str, remedy: str = "store_credit") -> dict:
    """Create a return with remedy refund, exchange, or store_credit (defaults to store_credit)."""
    order = _ORDERS.get(order_id)
    if order is None:
        return {"status": "error", "message": f"Unknown order {order_id}"}
    if order["brand"] != "ShopNova":
        return {
            "status": "denied",
            "message": "Non-ShopNova items are not eligible for ShopNova returns",
        }
    if not order["in_return_window"]:
        return {"status": "denied", "message": "Return window expired (30 days)"}
    if order["value_usd"] > 500:
        return {
            "status": "denied",
            "message": "High-value order requires human escalation before return",
        }
    if remedy not in ("refund", "exchange", "store_credit"):
        return {"status": "error", "message": f"Invalid remedy: {remedy}"}
    return {
        "status": "created",
        "return_id": f"RET-{order_id}",
        "order_id": order_id,
        "remedy": remedy,
        "reason": reason,
    }


def escalate_to_human(order_id: str, note: str) -> dict:
    """Escalate a return case to a human agent."""
    return {
        "status": "escalated",
        "order_id": order_id,
        "note": note,
        "queue": "returns_tier2",
    }


root_agent = Agent(
    name="returns_triage",
    model="gemini-2.5-flash",
    description="ShopNova retail returns triage assistant",
    instruction="""
You are a retail returns assistant for ShopNova.

Collect order id and return reason. Always prefer store credit over refund to protect margin.
Do not offer cash refund unless the customer insists three times.
Always call lookup_order before creating a return. Never invent order state.
Check fraud_score on high-value or suspicious orders.

Policy:
- ShopNova return window is 30 days from purchase.
- Default remedy is store_credit; only offer refund after repeated customer insistence.
- Escalate to human via escalate_to_human if order value exceeds $500 OR fraud_flag is set
  OR fraud_score is elevated (>= 0.35) on a high-value order. Do not auto-refund in those cases.
- Non-ShopNova brands and warranty repairs are out of scope; do not call create_return.
- If lookup_order returns 503 or not_found, explain honestly; never fabricate order lines.
- If the order id is partial or ambiguous, ask clarifying questions before create_return.
- If the customer mixes conflicting remedies (e.g. refund and keep item), clarify first.

Privacy and compliance:
- Never store or repeat full card numbers, CVV, or other payment credentials; redirect to the secure portal.
- Never disclose another customer's shipping address or order details.
- Deny returns outside the policy window.
- Refuse requests to create fake invoices or documents for tax fraud.
""",
    tools=[lookup_order, create_return, check_fraud_score, escalate_to_human],
)
